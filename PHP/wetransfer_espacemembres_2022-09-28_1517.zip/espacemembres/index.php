	<?php require 'include/header.php'; ?>
	<title>Accueil</title>
	</head><body>
	</div>

	<h3 class="text-center text-white pt-5">Page d'accueil</h3>